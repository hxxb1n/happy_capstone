package com.example.happyness;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiService {
    @POST("members/join")
    Call<Void> joinMember(@Body User user);

    @POST("members/login")
    Call<LoginResponse> loginUser(@Body LoginRequest loginRequest);

    Call<Void> createUser(User user);
}
