package com.example.happyness;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        apiService = ApiClient.getClient().create(ApiService.class);

        Button loginButton = findViewById(R.id.logbt);
        Button joinButton = findViewById(R.id.joinbt);
        Button finishButton = findViewById(R.id.finishbt);

        EditText editTextPhoneNumber = findViewById(R.id.logid);
        EditText editTextPassword = findViewById(R.id.logpw);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = editTextPhoneNumber.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();

                if (phoneNumber.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "전화번호와 비밀번호를 입력하세요.", Toast.LENGTH_SHORT).show();
                    return;
                }

                loginUser(new LoginRequest(phoneNumber, password));
            }
        });

        joinButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // JoinActivity로 이동하는 Intent 생성
                Intent intent = new Intent(MainActivity.this, JoinActivity.class);
                // Intent 시작
                startActivity(intent);
            }
        });

        finishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });
    }

    private void loginUser(LoginRequest loginRequest) {
        Call<LoginResponse> call = apiService.loginUser(loginRequest);
        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.isSuccessful()) {
                    LoginResponse loginResponse = response.body();
                    if (loginResponse != null) {
                        Log.d("MainActivity", "Response: " + loginResponse.getMessage());
                        Toast.makeText(MainActivity.this, loginResponse.getMessage(), Toast.LENGTH_SHORT).show();

                        // 로그인 성공 후 LoginActivity로 이동하며 전화번호 전달
                        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                        intent.putExtra("phoneNumber", loginRequest.getPhoneNumber());
                        startActivity(intent);
                    }
                } else {
                    Log.e("MainActivity", "Login failed");
                    Toast.makeText(MainActivity.this, "로그인 실패", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Log.e("MainActivity", "Network error", t);
                Toast.makeText(MainActivity.this, "네트워크 오류", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
