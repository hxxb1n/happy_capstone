package com.example.happyness;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Toast;

public class LoginActivity extends Activity {
    private WebView webView;
    private TextView welcomeTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        welcomeTextView = findViewById(R.id.welcomeTextView);
        webView = findViewById(R.id.webView);
        webView.setVerticalScrollBarEnabled(true);

        webView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return false;
            }
        });

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setSupportZoom(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // 페이지 로드가 완료되면 결제번호를 생성하기 위한 JavaScript 함수 호출
                webView.loadUrl("javascript:generateRandomNumber()");
            }
        });

        webView.addJavascriptInterface(new JavaScriptInterface(), "Android");

        // 웹뷰에 HTML 로드
        webView.loadUrl("file:///android_asset/webb.html");

        Button logbackButton = findViewById(R.id.loginbbt);
        logbackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // MainActivity로 되돌아가는 Intent 생성
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // 사용자 전화번호를 Intent에서 가져와서 환영 메시지 설정
        String phoneNumber = getIntent().getStringExtra("phoneNumber");
        if (phoneNumber != null) {
            welcomeTextView.setText(phoneNumber + "님 환영합니다.");
        }
    }

    // 자바스크립트와 상호작용하기 위한 인터페이스 정의
    public class JavaScriptInterface {
        @JavascriptInterface
        public void showToast(String paymentNumber) {
            // 결제번호를 토스트 메시지로 표시
            Toast.makeText(LoginActivity.this, "결제번호: " + paymentNumber, Toast.LENGTH_SHORT).show();
        }
    }
}
